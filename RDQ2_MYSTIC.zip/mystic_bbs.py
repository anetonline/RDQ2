def write(text):
    print(text)

def getstr(*args, **kwargs):
    return raw_input()

def writeln(text):
    print(text)

def getuser(index):
    return {"handle": "admin"}